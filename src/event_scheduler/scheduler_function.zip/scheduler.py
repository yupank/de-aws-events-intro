import json
import logging
import boto3
from datetime import datetime as dt

logger = logging.getLogger('MyLogger')
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    logger.info('content checked')
    logger.info(f'content checked:{dt.now().isoformat()}')
    logger.info(f'Content checked: {s3.list_buckets()["Buckets"]} ')
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from scheduled Lambda!')
    }
